#!/bin/bash
echo "Hello from the bash script!"
date