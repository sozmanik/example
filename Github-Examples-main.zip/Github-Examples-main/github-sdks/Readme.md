## List of features

We can install the following features in our codespace enviroment

https://containers.dev/features