

```
ssh-keygen -t rsa
ssh-keygen -t ed25519 
cat /home/codespace/.ssh/id_ed25519.pub
```